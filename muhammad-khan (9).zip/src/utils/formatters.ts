export function formatAED(amount: number | undefined | null): string {
  if (amount === undefined || amount === null || isNaN(amount)) return 'AED 0.00';
  return `AED ${amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr) return 'N/A';
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function getDaysUntil(dateStr?: string): number | null {
  if (!dateStr) return null;
  const target = new Date(dateStr);
  if (isNaN(target.getTime())) return null;
  const now = new Date();
  // reset hours to compare calendar days
  target.setHours(0, 0, 0, 0);
  now.setHours(0, 0, 0, 0);
  const diffTime = target.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getExpiryStatus(dateStr?: string): {
  status: 'valid' | 'expiring_soon' | 'expired';
  days: number | null;
  label: string;
  badgeClass: string;
} {
  const days = getDaysUntil(dateStr);
  if (days === null) {
    return {
      status: 'valid',
      days: null,
      label: 'Not Specified',
      badgeClass: 'bg-slate-800 text-slate-400 border-slate-700',
    };
  }

  if (days < 0) {
    return {
      status: 'expired',
      days,
      label: `Expired (${Math.abs(days)}d ago)`,
      badgeClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    };
  }

  if (days <= 30) {
    return {
      status: 'expiring_soon',
      days,
      label: `Expiring soon (${days}d left)`,
      badgeClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    };
  }

  return {
    status: 'valid',
    days,
    label: `Valid (${days}d left)`,
    badgeClass: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  };
}

export function maskName(fullName: string): string {
  if (!fullName) return '***';
  const parts = fullName.trim().split(/\s+/);
  return parts
    .map(p => {
      if (p.length <= 2) return p[0] + '*';
      return p[0] + '*'.repeat(Math.max(2, p.length - 2)) + p[p.length - 1];
    })
    .join(' ');
}

export function getNextInvoiceNumber(existingNumbers: string[], year: number = new Date().getFullYear()): string {
  const prefix = `CL-INV-${year}-`;
  let maxSeq = 0;

  for (const invNo of existingNumbers) {
    if (invNo && invNo.startsWith(prefix)) {
      const seqStr = invNo.substring(prefix.length);
      const seq = parseInt(seqStr, 10);
      if (!isNaN(seq) && seq > maxSeq) {
        maxSeq = seq;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return `${prefix}${nextSeq.toString().padStart(4, '0')}`;
}

export function getNextAgreementNumber(existingNumbers: string[], year: number = new Date().getFullYear()): string {
  const prefix = `CL-AGR-${year}-`;
  let maxSeq = 0;

  for (const agrNo of existingNumbers) {
    if (agrNo && agrNo.startsWith(prefix)) {
      const seqStr = agrNo.substring(prefix.length);
      const seq = parseInt(seqStr, 10);
      if (!isNaN(seq) && seq > maxSeq) {
        maxSeq = seq;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return `${prefix}${nextSeq.toString().padStart(4, '0')}`;
}

export function getTodayDubai(): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Dubai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}

export function getNextManpowerDealNumber(existingNumbers: string[], year: number = new Date().getFullYear()): string {
  const prefix = `CL-MP-${year}-`;
  let maxSeq = 0;

  for (const dealNo of existingNumbers) {
    if (dealNo && dealNo.startsWith(prefix)) {
      const seqStr = dealNo.substring(prefix.length);
      const seq = parseInt(seqStr, 10);
      if (!isNaN(seq) && seq > maxSeq) {
        maxSeq = seq;
      }
    }
  }

  const nextSeq = maxSeq + 1;
  return `${prefix}${nextSeq.toString().padStart(4, '0')}`;
}

export interface ComputedScheduleItem {
  id: string;
  dueDate: string;
  amount: number;
  notes?: string;
  allocated: number;
  remaining: number;
  isFullyPaid: boolean;
  isOverdue: boolean;
  overdueDays: number;
  isDueInNext7Days: boolean;
  isDueThisMonth: boolean;
}

export interface ComputedDealStatus {
  totalAgreed: number;
  totalReceived: number;
  balanceDue: number;
  isFullyPaid: boolean;
  isOverdue: boolean;
  overdueAmount: number;
  maxOverdueDays: number;
  overdueBadgeLabel: string | null;
  scheduleItems: ComputedScheduleItem[];
  hasUpcomingIn7Days: boolean;
  upcomingIn7DaysAmount: number;
  dueThisMonthAmount: number;
}

export function computeDealOverdueStatus(deal: {
  agreedAmount: number;
  status: string;
  startDate?: string;
  createdAt?: string;
  schedule?: Array<{ id: string; dueDate: string; amount: number; notes?: string }>;
  payments?: Array<{ amount: number }>;
}): ComputedDealStatus {
  const totalAgreed = Number(deal.agreedAmount) || 0;
  const totalReceived = (deal.payments || []).reduce((sum, p) => sum + (Number(p.amount) || 0), 0);
  const balanceDue = Math.max(0, totalAgreed - totalReceived);
  const isFullyPaid = balanceDue <= 0.001;
  const todayStr = getTodayDubai();
  const currentMonthStr = todayStr.substring(0, 7);

  // If deal is cancelled or fully paid, it has no active overdue amount
  if (deal.status === 'Cancelled' || isFullyPaid) {
    return {
      totalAgreed,
      totalReceived,
      balanceDue,
      isFullyPaid,
      isOverdue: false,
      overdueAmount: 0,
      maxOverdueDays: 0,
      overdueBadgeLabel: null,
      scheduleItems: (deal.schedule || []).map(s => ({
        ...s,
        allocated: s.amount,
        remaining: 0,
        isFullyPaid: true,
        isOverdue: false,
        overdueDays: 0,
        isDueInNext7Days: false,
        isDueThisMonth: false,
      })),
      hasUpcomingIn7Days: false,
      upcomingIn7DaysAmount: 0,
      dueThisMonthAmount: 0,
    };
  }

  const rawSchedule = [...(deal.schedule || [])].sort((a, b) => a.dueDate.localeCompare(b.dueDate));

  let remainingReceived = totalReceived;
  let overdueAmount = 0;
  let maxOverdueDays = 0;
  let hasUpcomingIn7Days = false;
  let upcomingIn7DaysAmount = 0;
  let dueThisMonthAmount = 0;

  const scheduleItems: ComputedScheduleItem[] = rawSchedule.map(item => {
    const itemAmount = Number(item.amount) || 0;
    const allocated = Math.min(itemAmount, Math.max(0, remainingReceived));
    remainingReceived -= allocated;
    const remaining = Math.max(0, itemAmount - allocated);
    const itemFullyPaid = remaining <= 0.001;

    let itemOverdue = false;
    let overdueDays = 0;
    let isDueInNext7Days = false;
    let isDueThisMonth = false;

    if (!itemFullyPaid) {
      if (item.dueDate < todayStr) {
        itemOverdue = true;
        const dueTime = new Date(item.dueDate).getTime();
        const todayTime = new Date(todayStr).getTime();
        overdueDays = Math.max(1, Math.round((todayTime - dueTime) / (1000 * 60 * 60 * 24)));
        overdueAmount += remaining;
        if (overdueDays > maxOverdueDays) {
          maxOverdueDays = overdueDays;
        }
      } else {
        const dueTime = new Date(item.dueDate).getTime();
        const todayTime = new Date(todayStr).getTime();
        const diffDays = Math.round((dueTime - todayTime) / (1000 * 60 * 60 * 24));
        if (diffDays >= 0 && diffDays <= 7) {
          isDueInNext7Days = true;
          hasUpcomingIn7Days = true;
          upcomingIn7DaysAmount += remaining;
        }
      }

      if (item.dueDate.startsWith(currentMonthStr)) {
        isDueThisMonth = true;
        dueThisMonthAmount += remaining;
      }
    }

    return {
      id: item.id,
      dueDate: item.dueDate,
      amount: itemAmount,
      notes: item.notes,
      allocated,
      remaining,
      isFullyPaid: itemFullyPaid,
      isOverdue: itemOverdue,
      overdueDays,
      isDueInNext7Days,
      isDueThisMonth,
    };
  });

  let isOverdue = overdueAmount > 0;
  let overdueBadgeLabel: string | null = null;

  if (isOverdue) {
    overdueBadgeLabel = `Overdue ${maxOverdueDays} days`;
  } else if (rawSchedule.length === 0 && balanceDue > 0) {
    // A deal with no schedule but a balance older than 30 days shows "Unscheduled balance"
    const dealDate = (deal.startDate || deal.createdAt || todayStr).split('T')[0];
    const dealTime = new Date(dealDate).getTime();
    const todayTime = new Date(todayStr).getTime();
    const daysOld = Math.round((todayTime - dealTime) / (1000 * 60 * 60 * 24));
    if (daysOld > 30) {
      isOverdue = true;
      overdueAmount = balanceDue;
      maxOverdueDays = daysOld;
      overdueBadgeLabel = 'Unscheduled balance';
    }
  }

  return {
    totalAgreed,
    totalReceived,
    balanceDue,
    isFullyPaid,
    isOverdue,
    overdueAmount,
    maxOverdueDays,
    overdueBadgeLabel,
    scheduleItems,
    hasUpcomingIn7Days,
    upcomingIn7DaysAmount,
    dueThisMonthAmount,
  };
}
