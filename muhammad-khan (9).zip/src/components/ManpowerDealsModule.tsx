import React, { useState, useMemo, useRef } from 'react';
import {
  User,
  CompanySettings,
  ManpowerDeal,
  ManpowerDealPayment,
  ManpowerDealScheduleItem,
  Employee,
  Transaction,
  PaymentMethod,
} from '../types.ts';
import { api } from '../services/api.ts';
import {
  formatAED,
  formatDate,
  getTodayDubai,
  getNextManpowerDealNumber,
  computeDealOverdueStatus,
  ComputedDealStatus,
} from '../utils/formatters.ts';
import { exportElementToPdf } from '../services/clientPdfService.ts';
import { ConfirmDeleteModal } from './ConfirmDeleteModal.tsx';
import { ManpowerDealStatementDocument } from './ManpowerDealStatementDocument.tsx';
import {
  Handshake,
  Plus,
  Search,
  Download,
  RefreshCw,
  AlertTriangle,
  Calendar,
  CheckCircle,
  Clock,
  User as UserIcon,
  Phone,
  Users,
  FileText,
  Eye,
  Edit,
  Trash2,
  X,
  Coins,
  Ban,
  TrendingUp,
  CreditCard,
  Building2,
  CalendarClock,
  Printer,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface ManpowerDealsModuleProps {
  currentUser: User;
  deals: ManpowerDeal[];
  employees: Employee[];
  transactions: Transaction[];
  settings: CompanySettings;
  onRefresh: () => Promise<void>;
}

export const ManpowerDealsModule: React.FC<ManpowerDealsModuleProps> = ({
  currentUser,
  deals = [],
  employees = [],
  transactions = [],
  settings,
  onRefresh,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'by_customer'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Open' | 'Completed' | 'Cancelled'>('All');
  const [onlyOverdue, setOnlyOverdue] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  // Modals & Drawers
  const [isNewDealModalOpen, setIsNewDealModalOpen] = useState(false);
  const [editingDeal, setEditingDeal] = useState<ManpowerDeal | null>(null);
  const [inspectingDeal, setInspectingDeal] = useState<ManpowerDeal | null>(null);
  const [paymentDeal, setPaymentDeal] = useState<ManpowerDeal | null>(null);
  const [editingPayment, setEditingPayment] = useState<{ deal: ManpowerDeal; payment: ManpowerDealPayment } | null>(null);

  // Delete Confirmation Modal
  const [deleteTarget, setDeleteTarget] = useState<{
    type: 'deal' | 'payment';
    id: string;
    dealId?: string;
    name: string;
  } | null>(null);

  // Printing / Exporting Statement State
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const statementRef = useRef<HTMLDivElement>(null);

  // Form States for New / Edit Deal
  const [formCustomerName, setFormCustomerName] = useState('');
  const [formCustomerPhone, setFormCustomerPhone] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formWorkersCount, setFormWorkersCount] = useState<number | ''>('');
  const [formLinkedEmployees, setFormLinkedEmployees] = useState<string[]>([]);
  const [formStartDate, setFormStartDate] = useState(getTodayDubai());
  const [formEndDate, setFormEndDate] = useState('');
  const [formAgreedAmount, setFormAgreedAmount] = useState<number | ''>('');
  const [formNotes, setFormNotes] = useState('');
  const [formSchedule, setFormSchedule] = useState<Array<{ id: string; dueDate: string; amount: number; notes: string }>>([]);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState('');

  // Form States for Payment
  const [paymentAmount, setPaymentAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Bank Transfer');
  const [paymentDate, setPaymentDate] = useState(getTodayDubai());
  const [paymentRefNo, setPaymentRefNo] = useState('');
  const [paymentNote, setPaymentNote] = useState('');
  const [paymentSubmitting, setPaymentSubmitting] = useState(false);
  const [paymentError, setPaymentError] = useState('');

  // Pre-computed deals status map
  const dealsWithStatus = useMemo(() => {
    return deals.map(deal => {
      const statusInfo = computeDealOverdueStatus(deal);
      return {
        ...deal,
        statusInfo,
      };
    });
  }, [deals]);

  // Overall Top Summary Metrics
  const summaryMetrics = useMemo(() => {
    let totalAgreed = 0;
    let totalReceived = 0;
    let totalOutstanding = 0;
    let totalOverdue = 0;
    let overdueDealsCount = 0;
    let dueNext7Days = 0;
    let dueThisMonth = 0;

    dealsWithStatus.forEach(d => {
      totalAgreed += Number(d.agreedAmount) || 0;
      totalReceived += d.statusInfo.totalReceived;

      if (d.status === 'Open') {
        totalOutstanding += d.statusInfo.balanceDue;
        if (d.statusInfo.isOverdue) {
          totalOverdue += d.statusInfo.overdueAmount;
          overdueDealsCount += 1;
        }
        dueNext7Days += d.statusInfo.upcomingIn7DaysAmount;
        dueThisMonth += d.statusInfo.dueThisMonthAmount;
      }
    });

    return {
      totalAgreed,
      totalReceived,
      totalOutstanding,
      totalOverdue,
      overdueDealsCount,
      dueNext7Days,
      dueThisMonth,
    };
  }, [dealsWithStatus]);

  // Filtered Deals for All Deals Tab
  const filteredDeals = useMemo(() => {
    return dealsWithStatus.filter(deal => {
      // Status filter
      if (statusFilter !== 'All' && deal.status !== statusFilter) return false;

      // Overdue filter
      if (onlyOverdue && !deal.statusInfo.isOverdue) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchName = deal.customerName.toLowerCase().includes(q);
        const matchNo = deal.dealNo.toLowerCase().includes(q);
        const matchDesc = (deal.description || '').toLowerCase().includes(q);
        const matchPhone = (deal.customerPhone || '').toLowerCase().includes(q);
        if (!matchName && !matchNo && !matchDesc && !matchPhone) return false;
      }

      return true;
    });
  }, [dealsWithStatus, statusFilter, onlyOverdue, searchQuery]);

  // Grouped Deals for "By Customer" Tab
  const customerGroups = useMemo(() => {
    const groups: Record<
      string,
      {
        customerName: string;
        phone?: string;
        deals: typeof dealsWithStatus;
        totalAgreed: number;
        totalReceived: number;
        balanceDue: number;
        overdueAmount: number;
        activeCount: number;
      }
    > = {};

    dealsWithStatus.forEach(deal => {
      const key = deal.customerName.trim().toLowerCase();
      if (!groups[key]) {
        groups[key] = {
          customerName: deal.customerName.trim(),
          phone: deal.customerPhone,
          deals: [],
          totalAgreed: 0,
          totalReceived: 0,
          balanceDue: 0,
          overdueAmount: 0,
          activeCount: 0,
        };
      }
      const g = groups[key];
      g.deals.push(deal);
      g.totalAgreed += Number(deal.agreedAmount) || 0;
      g.totalReceived += deal.statusInfo.totalReceived;
      if (deal.status === 'Open') {
        g.balanceDue += deal.statusInfo.balanceDue;
        g.activeCount += 1;
        if (deal.statusInfo.isOverdue) {
          g.overdueAmount += deal.statusInfo.overdueAmount;
        }
      }
      if (!g.phone && deal.customerPhone) {
        g.phone = deal.customerPhone;
      }
    });

    let list = Object.values(groups);

    // Apply search filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        g => g.customerName.toLowerCase().includes(q) || (g.phone && g.phone.toLowerCase().includes(q))
      );
    }

    // Sort by highest balance due descending
    list.sort((a, b) => b.balanceDue - a.balanceDue);
    return list;
  }, [dealsWithStatus, searchQuery]);

  // Refresh handler
  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await onRefresh();
    } finally {
      setRefreshing(false);
    }
  };

  // Open New Deal Modal
  const openNewDealModal = () => {
    setFormCustomerName('');
    setFormCustomerPhone('');
    setFormDescription('');
    setFormWorkersCount('');
    setFormLinkedEmployees([]);
    setFormStartDate(getTodayDubai());
    setFormEndDate('');
    setFormAgreedAmount('');
    setFormNotes('');
    setFormSchedule([]);
    setFormError('');
    setIsNewDealModalOpen(true);
  };

  // Open Edit Deal Modal
  const openEditDealModal = (deal: ManpowerDeal) => {
    setEditingDeal(deal);
    setFormCustomerName(deal.customerName);
    setFormCustomerPhone(deal.customerPhone || '');
    setFormDescription(deal.description);
    setFormWorkersCount(deal.workersCount !== undefined ? deal.workersCount : '');
    setFormLinkedEmployees(deal.linkedEmployeeIds || []);
    setFormStartDate(deal.startDate || getTodayDubai());
    setFormEndDate(deal.endDate || '');
    setFormAgreedAmount(deal.agreedAmount);
    setFormNotes(deal.notes || '');
    setFormSchedule(
      (deal.schedule || []).map(s => ({
        id: s.id,
        dueDate: s.dueDate,
        amount: s.amount,
        notes: s.notes || '',
      }))
    );
    setFormError('');
  };

  // Open Record Payment Modal
  const openRecordPaymentModal = (deal: ManpowerDeal) => {
    setPaymentDeal(deal);
    const statusInfo = computeDealOverdueStatus(deal);
    // Find first unpaid installment or default to remaining balance
    const nextUnpaid = statusInfo.scheduleItems.find(i => !i.isFullyPaid);
    const suggestedAmount = nextUnpaid ? nextUnpaid.remaining : statusInfo.balanceDue;
    setPaymentAmount(suggestedAmount > 0 ? suggestedAmount : '');
    setPaymentMethod('Bank Transfer');
    setPaymentDate(getTodayDubai());
    setPaymentRefNo('');
    setPaymentNote(`Payment for ${deal.customerName} - Deal #${deal.dealNo}`);
    setPaymentError('');
  };

  // Open Edit Payment Modal
  const openEditPaymentModal = (deal: ManpowerDeal, payment: ManpowerDealPayment) => {
    setEditingPayment({ deal, payment });
    setPaymentAmount(payment.amount);
    setPaymentMethod(payment.method);
    setPaymentDate(payment.date);
    setPaymentRefNo(payment.referenceNo || '');
    setPaymentNote(payment.note || '');
    setPaymentError('');
  };

  // Add Schedule Row to Form
  const addScheduleRow = () => {
    const today = getTodayDubai();
    setFormSchedule(prev => [
      ...prev,
      {
        id: `temp-${Date.now()}-${prev.length}`,
        dueDate: today,
        amount: 0,
        notes: `Installment #${prev.length + 1}`,
      },
    ]);
  };

  // Auto-generate Equal Monthly Schedule
  const autoGenerateSchedule = (numInstallments: number) => {
    const total = Number(formAgreedAmount);
    if (!total || total <= 0 || numInstallments <= 0) return;

    const baseAmount = Math.floor((total / numInstallments) * 100) / 100;
    const remainder = Math.round((total - baseAmount * numInstallments) * 100) / 100;

    const start = new Date(formStartDate || getTodayDubai());
    const items: Array<{ id: string; dueDate: string; amount: number; notes: string }> = [];

    for (let i = 0; i < numInstallments; i++) {
      const dueDate = new Date(start);
      dueDate.setMonth(start.getMonth() + i);
      const dueDateStr = dueDate.toISOString().split('T')[0];
      const amount = i === numInstallments - 1 ? baseAmount + remainder : baseAmount;

      items.push({
        id: `sch-${Date.now()}-${i}`,
        dueDate: dueDateStr,
        amount,
        notes: `Installment ${i + 1} of ${numInstallments}`,
      });
    }

    setFormSchedule(items);
  };

  // Handle Save New Deal
  const handleSaveNewDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCustomerName.trim()) {
      setFormError('Customer name is required.');
      return;
    }
    if (!formDescription.trim()) {
      setFormError('Deal description is required.');
      return;
    }
    const amount = Number(formAgreedAmount);
    if (!amount || amount <= 0) {
      setFormError('Agreed amount in AED must be greater than zero.');
      return;
    }

    setFormSubmitting(true);
    setFormError('');
    try {
      await api.createManpowerDeal(currentUser, {
        customerName: formCustomerName.trim(),
        customerPhone: formCustomerPhone.trim() || undefined,
        description: formDescription.trim(),
        workersCount: formWorkersCount !== '' ? Number(formWorkersCount) : undefined,
        linkedEmployeeIds: formLinkedEmployees,
        startDate: formStartDate,
        endDate: formEndDate || undefined,
        agreedAmount: amount,
        schedule: formSchedule.map((s, idx) => ({
          id: s.id.startsWith('temp-') ? `sch-${Date.now()}-${idx}` : s.id,
          dueDate: s.dueDate,
          amount: Number(s.amount) || 0,
          notes: s.notes?.trim() || undefined,
        })),
        notes: formNotes.trim() || undefined,
      });

      setIsNewDealModalOpen(false);
      await onRefresh();
    } catch (err: any) {
      setFormError(err.message || 'Failed to create manpower deal.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Handle Save Edited Deal
  const handleSaveEditDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDeal) return;

    if (!formCustomerName.trim()) {
      setFormError('Customer name is required.');
      return;
    }
    if (!formDescription.trim()) {
      setFormError('Deal description is required.');
      return;
    }
    const amount = Number(formAgreedAmount);
    if (!amount || amount <= 0) {
      setFormError('Agreed amount in AED must be greater than zero.');
      return;
    }

    setFormSubmitting(true);
    setFormError('');
    try {
      const updated = await api.updateManpowerDeal(currentUser, editingDeal.id, {
        customerName: formCustomerName.trim(),
        customerPhone: formCustomerPhone.trim() || undefined,
        description: formDescription.trim(),
        workersCount: formWorkersCount !== '' ? Number(formWorkersCount) : undefined,
        linkedEmployeeIds: formLinkedEmployees,
        startDate: formStartDate,
        endDate: formEndDate || undefined,
        agreedAmount: amount,
        schedule: formSchedule.map((s, idx) => ({
          id: s.id.startsWith('temp-') ? `sch-${Date.now()}-${idx}` : s.id,
          dueDate: s.dueDate,
          amount: Number(s.amount) || 0,
          notes: s.notes?.trim() || undefined,
        })),
        notes: formNotes.trim() || undefined,
      });

      setEditingDeal(null);
      if (inspectingDeal && inspectingDeal.id === editingDeal.id) {
        setInspectingDeal(updated);
      }
      await onRefresh();
    } catch (err: any) {
      setFormError(err.message || 'Failed to update manpower deal.');
    } finally {
      setFormSubmitting(false);
    }
  };

  // Handle Cancel Deal Action
  const handleCancelDeal = async (deal: ManpowerDeal) => {
    if (!window.confirm(`Are you sure you want to mark Deal #${deal.dealNo} (${deal.customerName}) as CANCELLED?`)) {
      return;
    }
    try {
      const updated = await api.cancelManpowerDeal(currentUser, deal.id);
      if (inspectingDeal && inspectingDeal.id === deal.id) {
        setInspectingDeal(updated);
      }
      await onRefresh();
    } catch (err: any) {
      alert(err.message || 'Failed to cancel deal.');
    }
  };

  // Handle Record Payment
  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentDeal) return;

    const amount = Number(paymentAmount);
    if (!amount || amount <= 0) {
      setPaymentError('Valid payment amount in AED is required.');
      return;
    }

    setPaymentSubmitting(true);
    setPaymentError('');
    try {
      const result = await api.recordDealPayment(currentUser, paymentDeal.id, {
        amount,
        method: paymentMethod,
        date: paymentDate || getTodayDubai(),
        referenceNo: paymentRefNo.trim() || undefined,
        note: paymentNote.trim() || undefined,
      });

      setPaymentDeal(null);
      if (inspectingDeal && inspectingDeal.id === paymentDeal.id) {
        setInspectingDeal(result.deal);
      }
      await onRefresh();
    } catch (err: any) {
      setPaymentError(err.message || 'Failed to record payment.');
    } finally {
      setPaymentSubmitting(false);
    }
  };

  // Handle Edit Payment
  const handleSaveEditPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;

    const amount = Number(paymentAmount);
    if (!amount || amount <= 0) {
      setPaymentError('Valid payment amount in AED is required.');
      return;
    }

    setPaymentSubmitting(true);
    setPaymentError('');
    try {
      const result = await api.updateDealPayment(currentUser, editingPayment.deal.id, editingPayment.payment.id, {
        amount,
        method: paymentMethod,
        date: paymentDate || getTodayDubai(),
        referenceNo: paymentRefNo.trim() || undefined,
        note: paymentNote.trim() || undefined,
      });

      setEditingPayment(null);
      if (inspectingDeal && inspectingDeal.id === editingPayment.deal.id) {
        setInspectingDeal(result.deal);
      }
      await onRefresh();
    } catch (err: any) {
      setPaymentError(err.message || 'Failed to update payment.');
    } finally {
      setPaymentSubmitting(false);
    }
  };

  // Export CSV for All Deals
  const handleExportDealsCsv = () => {
    const headers = [
      'Deal No',
      'Customer Name',
      'Customer Phone',
      'Description',
      'Workers Count',
      'Start Date',
      'End Date',
      'Agreed Amount (AED)',
      'Received Amount (AED)',
      'Balance Due (AED)',
      'Status',
      'Overdue Status',
      'Overdue Amount (AED)',
    ];

    const rows = filteredDeals.map(d => [
      d.dealNo,
      `"${d.customerName.replace(/"/g, '""')}"`,
      d.customerPhone || '',
      `"${d.description.replace(/"/g, '""')}"`,
      d.workersCount || '',
      d.startDate || '',
      d.endDate || '',
      d.agreedAmount,
      d.statusInfo.totalReceived,
      d.statusInfo.balanceDue,
      d.status,
      d.statusInfo.overdueBadgeLabel || 'Current',
      d.statusInfo.overdueAmount,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Manpower_Deals_Report_${getTodayDubai()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export CSV for Customer Summary
  const handleExportCustomersCsv = () => {
    const headers = [
      'Customer Name',
      'Contact Phone',
      'Active Deals Count',
      'Total Agreed (AED)',
      'Total Received (AED)',
      'Total Balance Due (AED)',
      'Overdue Amount (AED)',
    ];

    const rows = customerGroups.map(g => [
      `"${g.customerName.replace(/"/g, '""')}"`,
      g.phone || '',
      g.activeCount,
      g.totalAgreed,
      g.totalReceived,
      g.balanceDue,
      g.overdueAmount,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Manpower_Customers_Receivables_${getTodayDubai()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Download Statement PDF using exportElementToPdf
  const handleDownloadStatement = async () => {
    if (!inspectingDeal || !statementRef.current) return;
    setDownloadingPdf(true);
    try {
      const filename = `Statement-${inspectingDeal.dealNo}-${inspectingDeal.customerName.replace(/[\s\W]+/g, '_')}.pdf`;
      await exportElementToPdf(statementRef.current, filename, {
        documentTitle: 'Customer Statement of Account',
        serialNumber: inspectingDeal.dealNo,
        tradeName: settings.tradeNameEn,
      });
    } catch (err: any) {
      alert(err.message || 'Failed to generate Customer Statement PDF.');
    } finally {
      setDownloadingPdf(false);
    }
  };

  // Linked Expenses & Profit calculation for the inspected deal
  const inspectedDealFinancials = useMemo(() => {
    if (!inspectingDeal) return null;
    const statusInfo = computeDealOverdueStatus(inspectingDeal);
    const linkedExpenses = transactions.filter(
      t => t.relatedDealId === inspectingDeal.id && t.type === 'expense'
    );
    const totalExpenses = linkedExpenses.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    const netProfit = statusInfo.totalReceived - totalExpenses;
    const profitMargin = statusInfo.totalReceived > 0 ? (netProfit / statusInfo.totalReceived) * 100 : 0;

    return {
      statusInfo,
      linkedExpenses,
      totalExpenses,
      netProfit,
      profitMargin,
    };
  }, [inspectingDeal, transactions]);

  return (
    <div className="space-y-6 animate-fade-in text-slate-100">
      {/* Module Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0A1A3C] p-5 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-[#C9A05C] to-amber-600 rounded-xl text-slate-950 shadow-md">
            <Handshake className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white tracking-wide">Manpower Deals & Dues</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-500/15 text-[#C9A05C] border border-[#C9A05C]/30">
                Master Admin Only
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5 font-arabic">
              إدارة وتتبع مستحقات عمالة التوريد، جداول الدفعات، والتحصيل المالي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition cursor-pointer border border-slate-700 disabled:opacity-50"
            title="Refresh database records"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={openNewDealModal}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#C9A05C] to-amber-600 text-slate-950 rounded-lg text-xs font-bold hover:brightness-110 transition shadow-lg cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ New Manpower Deal</span>
          </button>
        </div>
      </div>

      {/* Top Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
        {/* Total Agreed */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Coins className="w-3.5 h-3.5 text-slate-400" />
            <span>Total Agreed</span>
          </div>
          <div className="text-lg font-extrabold text-white mt-1">
            {formatAED(summaryMetrics.totalAgreed)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">{deals.length} Total Deals</div>
        </div>

        {/* Total Received */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
            <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Total Received</span>
          </div>
          <div className="text-lg font-extrabold text-emerald-400 mt-1">
            {formatAED(summaryMetrics.totalReceived)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Recorded in Ledger</div>
        </div>

        {/* Total Outstanding */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Total Outstanding</span>
          </div>
          <div className="text-lg font-extrabold text-amber-400 mt-1">
            {formatAED(summaryMetrics.totalOutstanding)}
          </div>
          <div className="text-[10px] text-slate-500 mt-0.5">Active Receivables</div>
        </div>

        {/* Overdue Amount & Count */}
        <div className="bg-rose-950/20 border border-rose-500/30 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-rose-400 uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Overdue</span>
            </span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300">
              {summaryMetrics.overdueDealsCount} {summaryMetrics.overdueDealsCount === 1 ? 'deal' : 'deals'}
            </span>
          </div>
          <div className="text-lg font-extrabold text-rose-400 mt-1">
            {formatAED(summaryMetrics.totalOverdue)}
          </div>
          <div className="text-[10px] text-rose-300/80 mt-0.5">Requires Immediate Collection</div>
        </div>

        {/* Due in next 7 days */}
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <CalendarClock className="w-3.5 h-3.5" />
            <span>Due Next 7 Days</span>
          </div>
          <div className="text-lg font-extrabold text-amber-300 mt-1">
            {formatAED(summaryMetrics.dueNext7Days)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Upcoming Installments</div>
        </div>

        {/* Due this month */}
        <div className="bg-blue-950/20 border border-blue-500/30 rounded-xl p-3.5 shadow-sm">
          <div className="text-[11px] font-semibold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" />
            <span>Due This Month</span>
          </div>
          <div className="text-lg font-extrabold text-blue-300 mt-1">
            {formatAED(summaryMetrics.dueThisMonth)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Current Month Schedule</div>
        </div>
      </div>

      {/* Main Tabs Navigation & Filter Controls */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-[#C9A05C] text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              All Deals & Dues ({deals.length})
            </button>
            <button
              onClick={() => setActiveTab('by_customer')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeTab === 'by_customer'
                  ? 'bg-[#C9A05C] text-slate-950 shadow-md'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              By Customer ({customerGroups.length})
            </button>
          </div>

          <div className="flex items-center gap-2">
            {activeTab === 'all' ? (
              <button
                onClick={handleExportDealsCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition border border-slate-700 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            ) : (
              <button
                onClick={handleExportCustomersCsv}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition border border-slate-700 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Customers CSV</span>
              </button>
            )}
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search box */}
          <div className="relative flex-1 min-w-[240px]">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={activeTab === 'all' ? 'Search by Customer, Deal #, phone...' : 'Search customers...'}
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#C9A05C]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {activeTab === 'all' && (
            <>
              {/* Status filter */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 border border-slate-800 rounded-lg text-xs">
                {(['All', 'Open', 'Completed', 'Cancelled'] as const).map(st => (
                  <button
                    key={st}
                    onClick={() => setStatusFilter(st)}
                    className={`px-2.5 py-1 rounded text-xs font-medium transition cursor-pointer ${
                      statusFilter === st
                        ? 'bg-[#0A1A3C] text-[#C9A05C] font-bold border border-[#C9A05C]/30'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>

              {/* Overdue toggle */}
              <label className="flex items-center gap-2 text-xs text-slate-300 bg-slate-950 px-3 py-2 border border-slate-800 rounded-lg cursor-pointer hover:border-slate-700">
                <input
                  type="checkbox"
                  checked={onlyOverdue}
                  onChange={e => setOnlyOverdue(e.target.checked)}
                  className="rounded text-rose-500 focus:ring-0 bg-slate-900 border-slate-700"
                />
                <span className={onlyOverdue ? 'text-rose-400 font-bold' : ''}>
                  Overdue Only ({summaryMetrics.overdueDealsCount})
                </span>
              </label>
            </>
          )}
        </div>

        {/* TAB 1: ALL DEALS TABLE */}
        {activeTab === 'all' && (
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#0A1A3C] text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                <tr>
                  <th className="p-3">Deal #</th>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Service Scope</th>
                  <th className="p-3 text-right">Agreed</th>
                  <th className="p-3 text-right">Received</th>
                  <th className="p-3 text-right">Balance Due</th>
                  <th className="p-3 text-center">Schedule / Overdue Status</th>
                  <th className="p-3 text-center">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-950/40">
                {filteredDeals.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-500 italic">
                      No manpower deals match the selected criteria.
                    </td>
                  </tr>
                ) : (
                  filteredDeals.map(deal => {
                    const st = deal.statusInfo;
                    return (
                      <tr key={deal.id} className="hover:bg-slate-900/60 transition">
                        {/* Deal No */}
                        <td className="p-3 font-mono font-bold text-[#C9A05C]">
                          <button
                            onClick={() => setInspectingDeal(deal)}
                            className="hover:underline cursor-pointer"
                            title="Inspect Deal Details"
                          >
                            {deal.dealNo}
                          </button>
                        </td>

                        {/* Customer */}
                        <td className="p-3">
                          <div className="font-bold text-white">{deal.customerName}</div>
                          {deal.customerPhone && (
                            <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                              <Phone className="w-3 h-3" />
                              <span>{deal.customerPhone}</span>
                            </div>
                          )}
                        </td>

                        {/* Description & Workers */}
                        <td className="p-3 max-w-[200px]">
                          <div className="truncate text-slate-200" title={deal.description}>
                            {deal.description}
                          </div>
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            {deal.workersCount ? `${deal.workersCount} Workers` : 'Staffing'} • {formatDate(deal.startDate)}
                          </div>
                        </td>

                        {/* Agreed */}
                        <td className="p-3 text-right font-semibold text-white">
                          {formatAED(deal.agreedAmount)}
                        </td>

                        {/* Received */}
                        <td className="p-3 text-right font-semibold text-emerald-400">
                          {formatAED(st.totalReceived)}
                        </td>

                        {/* Balance Due */}
                        <td className="p-3 text-right font-bold">
                          {st.balanceDue > 0 ? (
                            <span className={st.isOverdue ? 'text-rose-400' : 'text-amber-400'}>
                              {formatAED(st.balanceDue)}
                            </span>
                          ) : (
                            <span className="text-slate-500 font-normal">AED 0.00</span>
                          )}
                        </td>

                        {/* Schedule / Overdue Status */}
                        <td className="p-3 text-center">
                          {deal.status === 'Cancelled' ? (
                            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-500">
                              Cancelled
                            </span>
                          ) : st.isFullyPaid ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                              <CheckCircle className="w-3 h-3" />
                              <span>Fully Paid</span>
                            </span>
                          ) : st.isOverdue ? (
                            <div className="inline-flex flex-col items-center">
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40 animate-pulse">
                                <AlertTriangle className="w-3 h-3" />
                                <span>{st.overdueBadgeLabel}</span>
                              </span>
                              <span className="text-[10px] text-rose-300 font-bold mt-0.5">
                                {formatAED(st.overdueAmount)}
                              </span>
                            </div>
                          ) : st.hasUpcomingIn7Days ? (
                            <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                              Due in 7d ({formatAED(st.upcomingIn7DaysAmount)})
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-400">
                              {deal.schedule.length} installments
                            </span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="p-3 text-center">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                              deal.status === 'Completed'
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                : deal.status === 'Cancelled'
                                ? 'bg-slate-800 text-slate-400 border border-slate-700'
                                : 'bg-blue-500/15 text-blue-400 border border-blue-500/30'
                            }`}
                          >
                            {deal.status}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button
                              onClick={() => setInspectingDeal(deal)}
                              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition cursor-pointer"
                              title="Inspect Deal & Customer Statement"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>

                            {deal.status === 'Open' && (
                              <button
                                onClick={() => openRecordPaymentModal(deal)}
                                className="p-1.5 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 rounded transition cursor-pointer"
                                title="Record Payment"
                              >
                                <CreditCard className="w-3.5 h-3.5" />
                              </button>
                            )}

                            <button
                              onClick={() => openEditDealModal(deal)}
                              className="p-1.5 text-slate-400 hover:text-[#C9A05C] hover:bg-slate-800 rounded transition cursor-pointer"
                              title="Edit Deal"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>

                            {deal.status === 'Open' && (
                              <button
                                onClick={() => handleCancelDeal(deal)}
                                className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-950/30 rounded transition cursor-pointer"
                                title="Cancel Deal"
                              >
                                <Ban className="w-3.5 h-3.5" />
                              </button>
                            )}

                            <button
                              onClick={() => {
                                if (deal.payments && deal.payments.length > 0) {
                                  alert('Deals with recorded payments cannot be deleted. Please mark the deal as Cancelled instead.');
                                  return;
                                }
                                setDeleteTarget({
                                  type: 'deal',
                                  id: deal.id,
                                  name: `Manpower Deal ${deal.dealNo} (${deal.customerName})`,
                                });
                              }}
                              className={`p-1.5 rounded transition cursor-pointer ${
                                deal.payments && deal.payments.length > 0
                                  ? 'text-slate-600 hover:text-slate-500'
                                  : 'text-slate-500 hover:text-rose-400 hover:bg-rose-950/30'
                              }`}
                              title={
                                deal.payments && deal.payments.length > 0
                                  ? 'Cannot delete deal with payments'
                                  : 'Permanently Delete Deal'
                              }
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* TAB 2: BY CUSTOMER TABLE */}
        {activeTab === 'by_customer' && (
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-[#0A1A3C] text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                <tr>
                  <th className="p-3">Customer / Organization</th>
                  <th className="p-3">Contact Phone</th>
                  <th className="p-3 text-center">Deals Count</th>
                  <th className="p-3 text-right">Total Agreed</th>
                  <th className="p-3 text-right">Total Received</th>
                  <th className="p-3 text-right">Total Balance Due</th>
                  <th className="p-3 text-right">Overdue Amount</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-950/40">
                {customerGroups.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-500 italic">
                      No customer receivables found.
                    </td>
                  </tr>
                ) : (
                  customerGroups.map((g, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/60 transition">
                      <td className="p-3 font-bold text-white flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-slate-500" />
                        <span>{g.customerName}</span>
                      </td>
                      <td className="p-3 text-slate-400">{g.phone || '—'}</td>
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-800 text-slate-300">
                          {g.deals.length} deals ({g.activeCount} active)
                        </span>
                      </td>
                      <td className="p-3 text-right font-semibold text-white">{formatAED(g.totalAgreed)}</td>
                      <td className="p-3 text-right font-semibold text-emerald-400">{formatAED(g.totalReceived)}</td>
                      <td className="p-3 text-right font-bold">
                        {g.balanceDue > 0 ? (
                          <span className={g.overdueAmount > 0 ? 'text-rose-400' : 'text-amber-400'}>
                            {formatAED(g.balanceDue)}
                          </span>
                        ) : (
                          <span className="text-slate-500">AED 0.00</span>
                        )}
                      </td>
                      <td className="p-3 text-right font-bold text-rose-400">
                        {g.overdueAmount > 0 ? formatAED(g.overdueAmount) : '—'}
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => {
                            setSearchQuery(g.customerName);
                            setActiveTab('all');
                          }}
                          className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded font-semibold transition cursor-pointer"
                        >
                          View Deals
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ==================== INSPECT DEAL MODAL / SLIDE-OVER ==================== */}
      {inspectingDeal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="w-full max-w-4xl max-h-[92vh] bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto">
            {/* Header */}
            <div className="p-4 sm:p-5 bg-[#0A1A3C] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-gradient-to-br from-[#C9A05C] to-amber-600 rounded-xl text-slate-950">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-white">
                      Deal Details: <span className="font-mono text-[#C9A05C]">{inspectingDeal.dealNo}</span>
                    </h3>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        inspectingDeal.status === 'Completed'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : inspectingDeal.status === 'Cancelled'
                          ? 'bg-slate-800 text-slate-400 border border-slate-700'
                          : 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                      }`}
                    >
                      {inspectingDeal.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">{inspectingDeal.customerName}</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleDownloadStatement}
                  disabled={downloadingPdf}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#C9A05C] hover:bg-amber-500 text-slate-950 font-bold rounded-lg text-xs transition cursor-pointer shadow disabled:opacity-50"
                  title="Download Customer Statement PDF"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{downloadingPdf ? 'Exporting...' : 'Statement PDF'}</span>
                </button>

                <button
                  onClick={() => setInspectingDeal(null)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 p-5 overflow-y-auto space-y-6">
              {/* Top Financial Breakdown Cards */}
              {inspectedDealFinancials && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] uppercase font-bold text-slate-400">Agreed Value</span>
                    <div className="text-base font-extrabold text-white mt-0.5">
                      {formatAED(inspectedDealFinancials.statusInfo.totalAgreed)}
                    </div>
                  </div>

                  <div className="bg-emerald-950/20 p-3 rounded-xl border border-emerald-500/30 text-center">
                    <span className="text-[10px] uppercase font-bold text-emerald-400">Total Received</span>
                    <div className="text-base font-extrabold text-emerald-400 mt-0.5">
                      {formatAED(inspectedDealFinancials.statusInfo.totalReceived)}
                    </div>
                  </div>

                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
                    <span className="text-[10px] uppercase font-bold text-amber-400">Balance Due</span>
                    <div className="text-base font-extrabold text-amber-400 mt-0.5">
                      {formatAED(inspectedDealFinancials.statusInfo.balanceDue)}
                    </div>
                  </div>

                  {/* Per-Deal Net Profit */}
                  <div className="bg-blue-950/20 p-3 rounded-xl border border-blue-500/30 text-center">
                    <span className="text-[10px] uppercase font-bold text-blue-400">Net Profit</span>
                    <div className="text-base font-extrabold text-blue-300 mt-0.5">
                      {formatAED(inspectedDealFinancials.netProfit)}
                    </div>
                    <span className="text-[9px] text-slate-400">
                      Margin: {inspectedDealFinancials.profitMargin.toFixed(1)}% (Cost: {formatAED(inspectedDealFinancials.totalExpenses)})
                    </span>
                  </div>
                </div>
              )}

              {/* Deal Overview Info */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-500 block uppercase text-[10px] font-bold">Scope / Description:</span>
                  <span className="text-white font-medium block mt-0.5">{inspectingDeal.description}</span>
                  {inspectingDeal.customerPhone && (
                    <span className="text-slate-400 block mt-1">Tel: {inspectingDeal.customerPhone}</span>
                  )}
                  {inspectingDeal.notes && (
                    <div className="mt-2 text-slate-400 italic bg-slate-900 p-2 rounded border border-slate-800">
                      Notes: {inspectingDeal.notes}
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <div>
                    <span className="text-slate-500">Period: </span>
                    <span className="text-slate-200">
                      {formatDate(inspectingDeal.startDate)} {inspectingDeal.endDate ? `to ${formatDate(inspectingDeal.endDate)}` : '(Ongoing)'}
                    </span>
                  </div>
                  {inspectingDeal.workersCount !== undefined && (
                    <div>
                      <span className="text-slate-500">Workers Count: </span>
                      <span className="text-slate-200 font-bold">{inspectingDeal.workersCount}</span>
                    </div>
                  )}
                  {inspectingDeal.linkedEmployeeIds && inspectingDeal.linkedEmployeeIds.length > 0 && (
                    <div>
                      <span className="text-slate-500">Deployed Employees: </span>
                      <span className="text-slate-200">
                        {inspectingDeal.linkedEmployeeIds
                          .map(id => employees.find(e => e.id === id)?.nameEn || id)
                          .join(', ')}
                      </span>
                    </div>
                  )}
                  <div>
                    <span className="text-slate-500">Created by: </span>
                    <span className="text-slate-400">{inspectingDeal.createdByName || 'Admin'} on {formatDate(inspectingDeal.createdAt)}</span>
                  </div>
                </div>
              </div>

              {/* Installments Schedule */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#C9A05C]" />
                    <span>Payment Schedule & Overdue Tracking</span>
                  </h4>
                  {inspectedDealFinancials?.statusInfo.isOverdue && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse">
                      {inspectedDealFinancials.statusInfo.overdueBadgeLabel} • Overdue: {formatAED(inspectedDealFinancials.statusInfo.overdueAmount)}
                    </span>
                  )}
                </div>

                {inspectingDeal.schedule.length === 0 ? (
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-500 text-center italic">
                    No installments schedule configured.
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-slate-800">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase font-bold">
                        <tr>
                          <th className="p-2.5">Due Date</th>
                          <th className="p-2.5">Note</th>
                          <th className="p-2.5 text-right">Amount</th>
                          <th className="p-2.5 text-right">Allocated Paid</th>
                          <th className="p-2.5 text-right">Remaining</th>
                          <th className="p-2.5 text-center">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
                        {inspectedDealFinancials?.statusInfo.scheduleItems.map((item, idx) => (
                          <tr key={item.id || idx}>
                            <td className="p-2.5 font-medium text-white">{formatDate(item.dueDate)}</td>
                            <td className="p-2.5 text-slate-400">{item.notes || `Installment #${idx + 1}`}</td>
                            <td className="p-2.5 text-right font-semibold text-white">{formatAED(item.amount)}</td>
                            <td className="p-2.5 text-right text-emerald-400">{formatAED(item.allocated)}</td>
                            <td className="p-2.5 text-right font-bold">
                              {item.remaining > 0 ? (
                                <span className={item.isOverdue ? 'text-rose-400' : 'text-slate-300'}>
                                  {formatAED(item.remaining)}
                                </span>
                              ) : (
                                <span className="text-slate-500">AED 0.00</span>
                              )}
                            </td>
                            <td className="p-2.5 text-center">
                              {item.isFullyPaid ? (
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400">
                                  Paid
                                </span>
                              ) : item.isOverdue ? (
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-400">
                                  Overdue ({item.overdueDays}d)
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300">
                                  Upcoming
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Payments History */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <CreditCard className="w-4 h-4 text-emerald-400" />
                    <span>Recorded Payments History ({inspectingDeal.payments?.length || 0})</span>
                  </h4>

                  {inspectingDeal.status === 'Open' && (
                    <button
                      onClick={() => openRecordPaymentModal(inspectingDeal)}
                      className="flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs transition cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Record Payment</span>
                    </button>
                  )}
                </div>

                {(!inspectingDeal.payments || inspectingDeal.payments.length === 0) ? (
                  <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-500 text-center italic">
                    No payments recorded yet for this deal. Click "Record Payment" to log a collection.
                  </div>
                ) : (
                  <div className="overflow-x-auto rounded-lg border border-slate-800">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950 text-slate-400 text-[10px] uppercase font-bold">
                        <tr>
                          <th className="p-2.5">Date</th>
                          <th className="p-2.5">Method</th>
                          <th className="p-2.5">Ref #</th>
                          <th className="p-2.5">Note</th>
                          <th className="p-2.5 text-right">Amount</th>
                          <th className="p-2.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/80 bg-slate-900/40">
                        {inspectingDeal.payments.map(p => (
                          <tr key={p.id}>
                            <td className="p-2.5 font-medium text-white">{formatDate(p.date)}</td>
                            <td className="p-2.5 text-slate-300">{p.method}</td>
                            <td className="p-2.5 font-mono text-[11px] text-slate-400">{p.referenceNo || '—'}</td>
                            <td className="p-2.5 text-slate-400">{p.note || 'Deal Payment'}</td>
                            <td className="p-2.5 text-right font-extrabold text-emerald-400">{formatAED(p.amount)}</td>
                            <td className="p-2.5 text-right">
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => openEditPaymentModal(inspectingDeal, p)}
                                  className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition cursor-pointer"
                                  title="Edit Payment"
                                >
                                  <Edit className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={() => {
                                    setDeleteTarget({
                                      type: 'payment',
                                      id: p.id,
                                      dealId: inspectingDeal.id,
                                      name: `Payment of AED ${p.amount} on ${formatDate(p.date)}`,
                                    });
                                  }}
                                  className="p-1 text-slate-400 hover:text-rose-400 rounded hover:bg-slate-800 transition cursor-pointer"
                                  title="Delete Payment (Requires Password)"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Hidden Print Container for Customer Statement */}
              <div className="hidden">
                <div ref={statementRef}>
                  <ManpowerDealStatementDocument
                    deal={inspectingDeal}
                    settings={settings}
                    employees={employees}
                  />
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
              <button
                onClick={() => openEditDealModal(inspectingDeal)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit Deal Info</span>
              </button>

              <button
                onClick={() => setInspectingDeal(null)}
                className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== NEW / EDIT DEAL MODAL ==================== */}
      {(isNewDealModalOpen || editingDeal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]">
            <div className="p-4 sm:p-5 bg-[#0A1A3C] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-gradient-to-br from-[#C9A05C] to-amber-600 rounded-xl text-slate-950">
                  <Handshake className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {editingDeal ? `Edit Deal #${editingDeal.dealNo}` : 'Create New Manpower Deal'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {editingDeal ? 'Update customer and schedule terms' : 'Add new manpower supply customer agreement'}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setIsNewDealModalOpen(false);
                  setEditingDeal(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={editingDeal ? handleSaveEditDeal : handleSaveNewDeal}
              className="flex-1 p-5 overflow-y-auto space-y-4 text-xs"
            >
              {formError && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 rounded-lg flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Customer Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Customer / Company Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Al Futtaim Contracting LLC"
                    value={formCustomerName}
                    onChange={e => setFormCustomerName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Customer Phone / Contact</label>
                  <input
                    type="text"
                    placeholder="e.g. 0501234567"
                    value={formCustomerPhone}
                    onChange={e => setFormCustomerPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>
              </div>

              {/* Scope & Agreed Amount */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-300 mb-1">
                    Description / Service Scope <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 5 laborers supplied to Project Site X"
                    value={formDescription}
                    onChange={e => setFormDescription(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Agreed Amount (AED) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    step="0.01"
                    placeholder="e.g. 15000"
                    value={formAgreedAmount}
                    onChange={e => setFormAgreedAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white font-bold text-amber-400 focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>
              </div>

              {/* Dates & Workers Count */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Start Date (Dubai Date)</label>
                  <input
                    type="date"
                    required
                    value={formStartDate}
                    onChange={e => setFormStartDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">End Date (Optional)</label>
                  <input
                    type="date"
                    value={formEndDate}
                    onChange={e => setFormEndDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Workers Count (Optional)</label>
                  <input
                    type="number"
                    min="1"
                    placeholder="e.g. 5"
                    value={formWorkersCount}
                    onChange={e => setFormWorkersCount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>
              </div>

              {/* Linked Employees from directory */}
              {employees.length > 0 && (
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">
                    Linked Employees from Directory (Optional)
                  </label>
                  <div className="max-h-28 overflow-y-auto bg-slate-950 border border-slate-800 rounded-lg p-2 space-y-1">
                    {employees.map(emp => {
                      const isSelected = formLinkedEmployees.includes(emp.id);
                      return (
                        <label
                          key={emp.id}
                          className="flex items-center gap-2 text-slate-300 hover:text-white cursor-pointer py-0.5 px-1 rounded hover:bg-slate-900"
                        >
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={e => {
                              if (e.target.checked) {
                                setFormLinkedEmployees(prev => [...prev, emp.id]);
                              } else {
                                setFormLinkedEmployees(prev => prev.filter(id => id !== emp.id));
                              }
                            }}
                            className="rounded text-amber-500 bg-slate-900 border-slate-700"
                          />
                          <span className="font-medium text-[11px]">{emp.nameEn}</span>
                          <span className="text-[10px] text-slate-500">
                            ({emp.position} - {emp.workingFor})
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Payment Schedule Builder */}
              <div className="border border-slate-800 rounded-xl p-3 bg-slate-950/60 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                  <div>
                    <span className="font-bold text-white uppercase text-[11px] tracking-wider block">
                      Installment Payment Schedule
                    </span>
                    <span className="text-[10px] text-slate-400">
                      Configure due dates for automated overdue alerts & statement breakdown
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Auto-generate buttons */}
                    <button
                      type="button"
                      onClick={() => autoGenerateSchedule(2)}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-semibold transition cursor-pointer"
                    >
                      2 Monthly
                    </button>
                    <button
                      type="button"
                      onClick={() => autoGenerateSchedule(3)}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-semibold transition cursor-pointer"
                    >
                      3 Monthly
                    </button>
                    <button
                      type="button"
                      onClick={addScheduleRow}
                      className="flex items-center gap-1 px-2.5 py-1 bg-[#C9A05C] hover:bg-amber-500 text-slate-950 rounded text-[10px] font-bold transition cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      <span>Add Row</span>
                    </button>
                  </div>
                </div>

                {formSchedule.length === 0 ? (
                  <div className="text-center py-3 text-slate-500 italic text-[11px]">
                    No installments added. You can add scheduled dates or leave empty.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {formSchedule.map((row, idx) => (
                      <div key={row.id || idx} className="grid grid-cols-12 gap-2 items-center bg-slate-900 p-2 rounded-lg border border-slate-800">
                        <div className="col-span-1 text-center font-bold text-slate-500 text-[10px]">
                          #{idx + 1}
                        </div>
                        <div className="col-span-4">
                          <input
                            type="date"
                            value={row.dueDate}
                            onChange={e => {
                              const val = e.target.value;
                              setFormSchedule(prev =>
                                prev.map((item, i) => (i === idx ? { ...item, dueDate: val } : item))
                              );
                            }}
                            className="w-full px-2 py-1 bg-slate-950 border border-slate-700 rounded text-white text-xs focus:outline-none"
                          />
                        </div>
                        <div className="col-span-3">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="Amount (AED)"
                            value={row.amount || ''}
                            onChange={e => {
                              const val = Number(e.target.value) || 0;
                              setFormSchedule(prev =>
                                prev.map((item, i) => (i === idx ? { ...item, amount: val } : item))
                              );
                            }}
                            className="w-full px-2 py-1 bg-slate-950 border border-slate-700 rounded text-white text-xs font-semibold focus:outline-none text-right"
                          />
                        </div>
                        <div className="col-span-3">
                          <input
                            type="text"
                            placeholder="Label / Note"
                            value={row.notes}
                            onChange={e => {
                              const val = e.target.value;
                              setFormSchedule(prev =>
                                prev.map((item, i) => (i === idx ? { ...item, notes: val } : item))
                              );
                            }}
                            className="w-full px-2 py-1 bg-slate-950 border border-slate-700 rounded text-slate-300 text-xs focus:outline-none"
                          />
                        </div>
                        <div className="col-span-1 text-center">
                          <button
                            type="button"
                            onClick={() => setFormSchedule(prev => prev.filter((_, i) => i !== idx))}
                            className="text-slate-500 hover:text-rose-400 p-1"
                            title="Remove"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}

                    <div className="flex justify-between items-center text-[11px] text-slate-400 px-1 pt-1">
                      <span>
                        Total Scheduled: <strong className="text-white">{formatAED(formSchedule.reduce((s, r) => s + (Number(r.amount) || 0), 0))}</strong>
                      </span>
                      {Number(formAgreedAmount) > 0 && (
                        <span>
                          Agreed: <strong className="text-[#C9A05C]">{formatAED(Number(formAgreedAmount))}</strong>
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Notes */}
              <div>
                <label className="block font-semibold text-slate-300 mb-1">Additional Internal Notes</label>
                <textarea
                  rows={2}
                  placeholder="Terms, special arrangements, contact persons..."
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsNewDealModalOpen(false);
                    setEditingDeal(null);
                  }}
                  disabled={formSubmitting}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-5 py-2 bg-gradient-to-r from-[#C9A05C] to-amber-600 text-slate-950 font-bold rounded-lg hover:brightness-110 transition shadow-lg cursor-pointer disabled:opacity-50"
                >
                  {formSubmitting
                    ? 'Saving...'
                    : editingDeal
                    ? 'Save Deal Changes'
                    : 'Create Manpower Deal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== RECORD / EDIT PAYMENT MODAL ==================== */}
      {(paymentDeal || editingPayment) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-sm animate-fade-in overflow-y-auto">
          <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto">
            <div className="p-4 sm:p-5 bg-[#0A1A3C] border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-emerald-400">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    {editingPayment ? 'Edit Payment Record' : 'Record Deal Payment'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Deal #{paymentDeal?.dealNo || editingPayment?.deal.dealNo} • {paymentDeal?.customerName || editingPayment?.deal.customerName}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPaymentDeal(null);
                  setEditingPayment(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={editingPayment ? handleSaveEditPayment : handleRecordPayment}
              className="p-5 space-y-4 text-xs"
            >
              {paymentError && (
                <div className="p-3 bg-rose-500/15 border border-rose-500/30 text-rose-300 rounded-lg flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{paymentError}</span>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-300 mb-1">
                  Payment Amount (AED) <span className="text-rose-400">*</span>
                </label>
                <input
                  type="number"
                  required
                  min="0.01"
                  step="0.01"
                  placeholder="0.00"
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white font-extrabold text-base text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Payment Method</label>
                  <select
                    value={paymentMethod}
                    onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  >
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Cheque">Cheque</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Payment Date (Dubai)</label>
                  <input
                    type="date"
                    required
                    value={paymentDate}
                    onChange={e => setPaymentDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Cheque / Bank Reference # (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. TR-998234 / CHQ-1002"
                  value={paymentRefNo}
                  onChange={e => setPaymentRefNo(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-300 mb-1">Notes / Description (Optional)</label>
                <input
                  type="text"
                  placeholder="Receipt note..."
                  value={paymentNote}
                  onChange={e => setPaymentNote(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-white focus:outline-none focus:border-[#C9A05C]"
                />
              </div>

              <div className="p-3 bg-emerald-950/20 border border-emerald-500/20 rounded-lg text-[11px] text-emerald-300/80">
                Notice: Recording this payment automatically logs an Income transaction under "Manpower Supply" in the financial ledger linked to this deal.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setPaymentDeal(null);
                    setEditingPayment(null);
                  }}
                  disabled={paymentSubmitting}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-semibold transition cursor-pointer"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={paymentSubmitting}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition shadow-lg cursor-pointer disabled:opacity-50"
                >
                  {paymentSubmitting ? 'Saving...' : editingPayment ? 'Update Payment' : 'Confirm & Log Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== DELETE CONFIRMATION MODAL WITH PASSWORD ==================== */}
      {deleteTarget && (
        <ConfirmDeleteModal
          isOpen={true}
          itemType={deleteTarget.id}
          itemName={deleteTarget.name}
          warningMessage={
            deleteTarget.type === 'deal'
              ? 'This deal will be permanently removed from Cloud Firestore. Note: Deals with payments cannot be deleted.'
              : 'This payment record and its matching entry in the financial ledger will be permanently removed.'
          }
          currentUser={currentUser}
          onClose={() => setDeleteTarget(null)}
          onConfirm={async () => {
            if (deleteTarget.type === 'deal') {
              await api.deleteManpowerDeal(currentUser, deleteTarget.id);
              if (inspectingDeal && inspectingDeal.id === deleteTarget.id) {
                setInspectingDeal(null);
              }
            } else if (deleteTarget.type === 'payment' && deleteTarget.dealId) {
              await api.deleteDealPayment(currentUser, deleteTarget.dealId, deleteTarget.id);
            }
            setDeleteTarget(null);
            await onRefresh();
          }}
        />
      )}
    </div>
  );
};
