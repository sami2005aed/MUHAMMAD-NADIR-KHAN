import React from 'react';
import { CompanySettings, ManpowerDeal, Employee } from '../types.ts';
import { formatAED, formatDate, computeDealOverdueStatus, getTodayDubai } from '../utils/formatters.ts';
import { OfficialLetterhead, OfficialFooter } from './OfficialLetterhead.tsx';

interface ManpowerDealStatementDocumentProps {
  deal: ManpowerDeal;
  settings: CompanySettings;
  employees?: Employee[];
  className?: string;
}

export const ManpowerDealStatementDocument: React.FC<ManpowerDealStatementDocumentProps> = ({
  deal,
  settings,
  employees = [],
  className = '',
}) => {
  const statusInfo = computeDealOverdueStatus(deal);
  const todayStr = getTodayDubai();
  const linkedWorkers = (deal.linkedEmployeeIds || [])
    .map(empId => employees.find(e => e.id === empId))
    .filter(Boolean) as Employee[];

  return (
    <div
      className={`bg-white text-slate-900 font-sans p-6 sm:p-8 select-text ${className}`}
      style={{ width: '100%', maxWidth: '794px', margin: '0 auto', boxSizing: 'border-box' }}
    >
      {/* Official Bilingual Header */}
      <div data-pdf-block="true">
        <OfficialLetterhead
          settings={settings}
          documentTitleEn="CUSTOMER STATEMENT OF ACCOUNT"
          documentTitleAr="كشف حساب العميل - خدمات توريد العمالة"
          serialNumber={deal.dealNo}
          issueDate={todayStr}
        />
      </div>

      {/* Customer & Deal Metadata Banner */}
      <div
        data-pdf-block="true"
        className="grid grid-cols-2 gap-4 bg-slate-50 border border-slate-300 rounded-lg p-4 mb-5 text-xs pdf-avoid-break"
      >
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Customer / Client Details (بيانات العميل)
          </div>
          <div className="text-sm font-extrabold text-[#0A1A3C] mt-0.5">{deal.customerName}</div>
          {deal.customerPhone && (
            <div className="text-slate-600 mt-0.5 font-medium">Tel / Contact: {deal.customerPhone}</div>
          )}
          <div className="text-slate-700 mt-1 font-semibold">
            <span className="text-slate-500 font-normal">Service Scope: </span>
            {deal.description}
          </div>
        </div>

        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
            Agreement Reference (مرجع الاتفاقية)
          </div>
          <div className="text-sm font-bold text-[#C9A05C] font-mono mt-0.5">{deal.dealNo}</div>
          <div className="text-slate-600 mt-0.5">
            Duration: {formatDate(deal.startDate)} {deal.endDate ? `to ${formatDate(deal.endDate)}` : '(Ongoing)'}
          </div>
          {deal.workersCount !== undefined && deal.workersCount > 0 && (
            <div className="text-slate-600 mt-0.5 font-medium">
              Manpower Count: <span className="font-bold text-slate-900">{deal.workersCount} Workers</span>
            </div>
          )}
          <div className="mt-1">
            <span
              className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider ${
                deal.status === 'Completed'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : deal.status === 'Cancelled'
                  ? 'bg-slate-200 text-slate-700 border border-slate-300'
                  : statusInfo.isOverdue
                  ? 'bg-rose-100 text-rose-800 border border-rose-300'
                  : 'bg-blue-100 text-blue-800 border border-blue-300'
              }`}
            >
              {deal.status === 'Open' && statusInfo.isOverdue
                ? `Account Due (${statusInfo.overdueBadgeLabel})`
                : `Status: ${deal.status}`}
            </span>
          </div>
        </div>
      </div>

      {/* Financial Summary Cards */}
      <div data-pdf-block="true" className="grid grid-cols-3 gap-3 mb-6 pdf-avoid-break">
        <div className="bg-slate-100 border border-slate-300 p-3 rounded-lg text-center">
          <span className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            Total Agreed Value
          </span>
          <span className="block text-base font-extrabold text-[#0A1A3C] mt-0.5">
            {formatAED(statusInfo.totalAgreed)}
          </span>
          <span className="block text-[9px] text-slate-500 font-arabic">القيمة الإجمالية المتفق عليها</span>
        </div>

        <div className="bg-emerald-50 border border-emerald-300 p-3 rounded-lg text-center">
          <span className="block text-[10px] font-bold text-emerald-700 uppercase tracking-wider">
            Total Received / Paid
          </span>
          <span className="block text-base font-extrabold text-emerald-700 mt-0.5">
            {formatAED(statusInfo.totalReceived)}
          </span>
          <span className="block text-[9px] text-emerald-600 font-arabic">إجمالي المبالغ المستلمة</span>
        </div>

        <div
          className={`p-3 rounded-lg text-center border ${
            statusInfo.balanceDue > 0
              ? 'bg-rose-50 border-rose-300 text-rose-700'
              : 'bg-slate-50 border-slate-300 text-slate-700'
          }`}
        >
          <span className="block text-[10px] font-bold uppercase tracking-wider">
            Outstanding Balance
          </span>
          <span className="block text-base font-extrabold mt-0.5">
            {formatAED(statusInfo.balanceDue)}
          </span>
          <span className="block text-[9px] opacity-80 font-arabic">الرصيد المتبقي المستحق</span>
        </div>
      </div>

      {/* Assigned Staff (if any) */}
      {linkedWorkers.length > 0 && (
        <div data-pdf-block="true" className="mb-6 pdf-avoid-break">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 border-b border-slate-300 pb-1 mb-2">
            Deployed Personnel / العمالة المخصصة
          </h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {linkedWorkers.map((w, idx) => (
              <div key={w.id || idx} className="bg-slate-50 border border-slate-200 rounded p-2 text-xs">
                <div className="font-bold text-slate-900">{w.nameEn}</div>
                <div className="text-[10px] text-slate-500">
                  {w.position} • {w.nationality || 'Staff'}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment Schedule Table */}
      {statusInfo.scheduleItems.length > 0 && (
        <div data-pdf-block="true" className="mb-6 pdf-avoid-break">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 border-b border-slate-300 pb-1 mb-2">
            Agreed Payment Schedule & Installments (جدول الدفعات المتفق عليها)
          </h4>
          <table className="w-full text-left text-xs border border-slate-300 rounded overflow-hidden">
            <thead className="bg-[#0A1A3C] text-white text-[11px] uppercase">
              <tr>
                <th className="p-2 border-r border-slate-700 w-12 text-center">#</th>
                <th className="p-2 border-r border-slate-700">Due Date / تاريخ الاستحقاق</th>
                <th className="p-2 border-r border-slate-700 text-right">Scheduled (AED)</th>
                <th className="p-2 border-r border-slate-700 text-right">Allocated (AED)</th>
                <th className="p-2 border-r border-slate-700 text-right">Remaining Due</th>
                <th className="p-2 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {statusInfo.scheduleItems.map((item, idx) => (
                <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-2 text-center font-bold text-slate-500 border-r border-slate-200">{idx + 1}</td>
                  <td className="p-2 border-r border-slate-200 font-medium">
                    {formatDate(item.dueDate)}
                    {item.notes && <span className="block text-[10px] text-slate-500">{item.notes}</span>}
                  </td>
                  <td className="p-2 text-right border-r border-slate-200 font-semibold">{formatAED(item.amount)}</td>
                  <td className="p-2 text-right border-r border-slate-200 text-emerald-700">{formatAED(item.allocated)}</td>
                  <td className="p-2 text-right border-r border-slate-200 font-bold">
                    {item.remaining > 0 ? (
                      <span className={item.isOverdue ? 'text-rose-600' : 'text-slate-900'}>
                        {formatAED(item.remaining)}
                      </span>
                    ) : (
                      <span className="text-emerald-600 font-normal">AED 0.00</span>
                    )}
                  </td>
                  <td className="p-2 text-center">
                    {item.isFullyPaid ? (
                      <span className="inline-block px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded">
                        PAID
                      </span>
                    ) : item.isOverdue ? (
                      <span className="inline-block px-2 py-0.5 bg-rose-100 text-rose-800 text-[10px] font-bold rounded">
                        OVERDUE ({item.overdueDays}d)
                      </span>
                    ) : (
                      <span className="inline-block px-2 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-bold rounded">
                        UPCOMING
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Payments Received History */}
      <div data-pdf-block="true" className="mb-6 pdf-avoid-break">
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 border-b border-slate-300 pb-1 mb-2">
          Receipts & Payment History (سجل الدفعات المستلمة)
        </h4>
        {(!deal.payments || deal.payments.length === 0) ? (
          <div className="p-3 bg-slate-50 border border-slate-200 rounded text-center text-xs text-slate-500 italic">
            No payments recorded yet against this agreement.
          </div>
        ) : (
          <table className="w-full text-left text-xs border border-slate-300 rounded overflow-hidden">
            <thead className="bg-slate-800 text-white text-[11px] uppercase">
              <tr>
                <th className="p-2 border-r border-slate-700 w-12 text-center">#</th>
                <th className="p-2 border-r border-slate-700">Date Received</th>
                <th className="p-2 border-r border-slate-700">Method</th>
                <th className="p-2 border-r border-slate-700">Reference No</th>
                <th className="p-2 border-r border-slate-700">Notes / Payer</th>
                <th className="p-2 text-right">Amount (AED)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-800">
              {deal.payments.map((p, idx) => (
                <tr key={p.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                  <td className="p-2 text-center font-bold text-slate-500 border-r border-slate-200">{idx + 1}</td>
                  <td className="p-2 border-r border-slate-200 font-medium">{formatDate(p.date)}</td>
                  <td className="p-2 border-r border-slate-200">{p.method}</td>
                  <td className="p-2 border-r border-slate-200 font-mono text-[11px]">
                    {p.referenceNo || '—'}
                  </td>
                  <td className="p-2 border-r border-slate-200 text-slate-600">
                    {p.note || 'Official Payment Receipt'}
                  </td>
                  <td className="p-2 text-right font-extrabold text-emerald-700">{formatAED(p.amount)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-extrabold text-xs border-t-2 border-slate-300">
                <td colSpan={5} className="p-2 text-right uppercase text-slate-700">
                  Total Received / المجموع المستلم:
                </td>
                <td className="p-2 text-right text-emerald-800 text-sm">
                  {formatAED(statusInfo.totalReceived)}
                </td>
              </tr>
            </tfoot>
          </table>
        )}
      </div>

      {/* Official Legal Notes & Signatures */}
      <div data-pdf-block="true" className="mt-8 border-t border-slate-300 pt-4 pdf-avoid-break text-xs">
        <div className="text-[10px] text-slate-500 mb-6">
          <p className="font-semibold text-slate-700">Terms & Verification / الشروط والتحقق:</p>
          <p className="mt-0.5">
            This statement is an official financial record issued by {settings.tradeNameEn} (License #{settings.licenseNo}).
            Payments should be remitted according to the agreed schedule. For payment confirmation or billing inquiries, please contact our accounts department at {settings.phones[0] || '068055093'}.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-8 text-center pt-2">
          <div>
            <div className="border-b border-slate-400 pb-12"></div>
            <div className="text-[11px] font-bold text-slate-800 mt-1">Authorized Signatory / Stamp</div>
            <div className="text-[10px] text-slate-500 font-arabic">{settings.tradeNameAr}</div>
          </div>
          <div>
            <div className="border-b border-slate-400 pb-12"></div>
            <div className="text-[11px] font-bold text-slate-800 mt-1">Customer Acknowledgment</div>
            <div className="text-[10px] text-slate-500 font-arabic">توقيع واستلام العميل / المفوض</div>
          </div>
        </div>
      </div>

      {/* Official UAE Footer Strip */}
      <div data-pdf-block="true" className="mt-8">
        <OfficialFooter settings={settings} />
      </div>
    </div>
  );
};
